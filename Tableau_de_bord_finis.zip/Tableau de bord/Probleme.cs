using System;


public class Probleme
{
    public int Id { get; set; }
    public string Titre { get; set; }
    public string Description { get; set; }
    public DateTime DateSignalement { get; set; }
    public string NiveauUrgence { get; set; }
}
